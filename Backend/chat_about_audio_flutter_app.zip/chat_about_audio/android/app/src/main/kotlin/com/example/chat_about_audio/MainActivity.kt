package com.example.chat_about_audio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
