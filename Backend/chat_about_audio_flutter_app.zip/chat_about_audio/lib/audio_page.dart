import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:chat_about_audio/audio_recorder_interface.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

// Import the audio recorder implementation based on the platform
import 'package:chat_about_audio/audio_recorder_web.dart' as web;
//import 'package:chat_about_audio/audio_recorder_mobile.dart' as mobile;

// Define the getRecorder function to return the correct recorder implementation
AudioRecorderInterface getRecorder() {
//if (kIsWeb) {
return web.WebAudioRecorder();
//} else {
//return mobile.MobileAudioRecorder();
//}
}

class AudioPage extends StatefulWidget {
@override
_AudioPageState createState() => _AudioPageState();
}

class _AudioPageState extends State<AudioPage> {
late AudioRecorderInterface recorder; // Declare the recorder
late Future<void> _recorderFuture;
String? _recordedFilePath;
bool _isRecording = false;
bool _isPlaying = false;
bool _hasAudioInput = false;
String? _audioFilePath;
double _sliderValue = 0.0;
Duration _audioDuration = Duration.zero;
Duration _currentPosition = Duration.zero;
String _summary = 'Audio summary will be generated here.';
final TextEditingController _chatController = TextEditingController();
final List<Map<String, String>> _chatHistory = [];

final FlutterSoundPlayer _player = FlutterSoundPlayer();

@override
void initState() {
super.initState();
recorder = getRecorder(); // Initialize the recorder based on the platform
_recorderFuture = _initializeRecorder(); // Initialize the recorder future
_player.openPlayer();
}

@override
void dispose() {
_player.closePlayer();
super.dispose();
}

Future<dynamic> _initializeRecorder() async {
await recorder.init(); // Initialize the recorder
}

Future<void> _startRecording() async {
setState(() {
_isRecording = true;
});
await recorder.startRecording();
setState(() {
_recordedFilePath = recorder.recordedFilePath;
});
}

Future<void> _stopRecording() async {
setState(() {
_isRecording = false;
});
await recorder.stopRecording();

if (_recordedFilePath != null) {
_initializeAudio(_recordedFilePath!);
_generateSummary();
}
}

Future<void> _pickAudioFile() async {
FilePickerResult? result = await FilePicker.platform.pickFiles(
type: FileType.audio,
);
if (result != null) {
_audioFilePath = result.files.single.path;
setState(() {
_hasAudioInput = true;
});
_initializeAudio(_audioFilePath!);
_generateSummary();
}
}

Future<void> _initializeAudio(String filePath) async {
_audioDuration = await _player.startPlayer(fromURI: filePath, codec: Codec.aacADTS) ?? Duration.zero;
setState(() {
_sliderValue = 0.0;
_currentPosition = Duration.zero;
});

_player.onProgress!.listen((event) {
setState(() {
_currentPosition = event.position;
_sliderValue = _currentPosition.inMilliseconds.toDouble() / _audioDuration.inMilliseconds.toDouble();
});
});

await _player.pausePlayer();
}

Future<void> _playAudio() async {
if (!_isPlaying) {
await _player.resumePlayer();
setState(() {
_isPlaying = true;
});
}
}

Future<void> _pauseAudio() async {
if (_isPlaying) {
await _player.pausePlayer();
setState(() {
_isPlaying = false;
});
}
}

Future<void> _seekAudio(double value) async {
int newPosition = (_audioDuration.inMilliseconds * value).toInt();
await _player.seekToPlayer(Duration(milliseconds: newPosition));
setState(() {
_sliderValue = value;
});
}

Future<void> _downloadAudio() async {
if (_recordedFilePath == null) {
return;
}

try {
Directory internalStorage = await getApplicationDocumentsDirectory();
String newFilePath = '${internalStorage.path}/audio_downloaded.aac';

File recordedFile = File(_recordedFilePath!);
File newFile = await recordedFile.copy(newFilePath);

ScaffoldMessenger.of(context).showSnackBar(
SnackBar(content: Text('Audio saved to internal storage: ${newFile.path}')),
);
} catch (e) {
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(content: Text('Failed to save audio: $e')),
);
}
}

void _generateSummary() {
setState(() {
_summary = 'This is a placeholder summary for the audio file.'; // Placeholder for actual summary logic
});
}

void _addChatMessage(String message) {
setState(() {
_chatHistory.add({'user': ':User  $message'});
_chatHistory.add({'system': 'System: Hello! How can I help you?'});
_chatController.clear();
});
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(title: const Text('Audio Recorder & Player')),
body: FutureBuilder<dynamic>(
future: _recorderFuture,
builder: (context, snapshot) {
if (snapshot.connectionState == ConnectionState.waiting) {
return Center(child: CircularProgressIndicator());
} else if (snapshot.hasError) {
return Center(child: Text('Error: ${snapshot.error}'));
} else {
return Container(
decoration: BoxDecoration(
image: DecorationImage(
image: AssetImage('assets/background.jpg'),
fit: BoxFit.cover,
),
),
child: Column(
children: [
Expanded(
child: Padding(
padding: const EdgeInsets.all(16.0),
child: Card(
elevation: 8,
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular(16),
),
child: Padding(
padding: const EdgeInsets.all(16.0),
child: Column(
mainAxisSize: MainAxisSize.min,
children: [
Text(
'Audio Recorder & Player',
style: TextStyle(
fontSize: 24,
fontWeight: FontWeight.bold,
),
),
SizedBox(height: 20),
Row(
mainAxisAlignment: MainAxisAlignment.spaceEvenly,
children: [
ElevatedButton(
onPressed: _isRecording ? _stopRecording : _startRecording,
child: Text(_isRecording ? 'Stop Recording' : 'Start Recording'),
style: ElevatedButton.styleFrom(
padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular(8),
),
),
),
ElevatedButton(
onPressed: _pickAudioFile,
child: Text('Upload Audio'),
style: ElevatedButton.styleFrom(
padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular(8),
),
),
),
],
),
SizedBox(height: 20),
ElevatedButton(
onPressed: _isPlaying ? _pauseAudio : _playAudio,
child: Text(_isPlaying ? 'Pause Audio' : 'Play Audio'),
style: ElevatedButton.styleFrom(
padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular(8),
),
),
),
SizedBox(height: 20),
if (_hasAudioInput)
Column(
children: [
Slider(
value: _sliderValue,
onChanged: (value) {
_seekAudio(value);
},
),
IconButton(
icon: Icon(Icons.download),
onPressed: _downloadAudio,
),
],
),
SizedBox(height: 20),
TextField(
decoration: InputDecoration(
labelText: 'Summary',
border: OutlineInputBorder(),
),
maxLines: 3,
readOnly: true,
controller: TextEditingController(text: _summary),
),
SizedBox(height: 20),
Expanded(
child: ListView.builder(
itemCount: _chatHistory.length,
itemBuilder: (context, index) {
return ListTile(
title: Text(_chatHistory[index]['user'] ?? _chatHistory[index]['system']!),
);
},
),
),
TextField(
controller: _chatController,
decoration: InputDecoration(
labelText: 'Type your message...',
suffixIcon: IconButton(
icon: Icon(Icons.send),
onPressed: () {
if (_chatController.text.isNotEmpty) {
_addChatMessage(_chatController.text);
}
},
),
),
),
],
),
),
),
),
),
],
),
);
}
},
),
);
}
}