import 'package:flutter/foundation.dart';

abstract class AudioRecorderInterface {
  Future<void> init();
  Future<void> startRecording();
  Future<void> stopRecording();
  Future<String?> getRecordedFilePath(); // A method to access the recorded file path
}
