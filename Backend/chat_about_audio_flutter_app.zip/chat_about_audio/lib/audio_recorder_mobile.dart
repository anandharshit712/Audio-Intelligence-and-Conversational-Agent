import 'package:flutter_sound/flutter_sound.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';
import 'package:chat_about_audio/audio_recorder_interface.dart';

class MobileAudioRecorder implements AudioRecorderInterface {
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  String? _recordedFilePath;

  @override
  Future<void> init() async {
    // Request microphone permission
    var status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      throw RecordingPermissionException('Microphone permission not granted');
    }

    // Open the audio session
    await _recorder.openRecorder();
  }

  @override
  String? get recordedFilePath {
    return _recordedFilePath;
  }

  @override
  Future<void> startRecording() async {
    if (!_recorder.isRecording) {
      final directory = await getApplicationDocumentsDirectory();
      _recordedFilePath = '${directory.path}/audio_${DateTime.now().millisecondsSinceEpoch}.aac';
      await _recorder.startRecorder(toFile: _recordedFilePath);
    } else {
      print('Recorder is already running.');
    }
  }

  @override
  Future<void> stopRecording() async {
    if (_recorder.isRecording) {
      await _recorder.stopRecorder();
    } else {
      print('Recorder is not running.');
    }
  }

  @override
  String? getRecordedFilePath() {
    return _recordedFilePath;
  }

  Future<void> dispose() async {
    await _recorder.closeRecorder();
  }
}

