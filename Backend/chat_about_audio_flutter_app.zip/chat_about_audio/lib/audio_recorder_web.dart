import 'dart:html' as html;
import 'package:chat_about_audio/audio_recorder_interface.dart';

class WebAudioRecorder implements AudioRecorderInterface {
  html.MediaRecorder? _mediaRecorder;
  html.MediaStream? _mediaStream;
  html.Blob? _audioBlob;
  String? _recordedFilePath;

  @override
  String? get recordedFilePath {
    return _recordedFilePath;
  }

  bool _isRecording = false;



  Future<void> init() async {
    try {
      _mediaStream = await html.window.navigator.mediaDevices?.getUserMedia({'audio': true});
      _mediaRecorder = html.MediaRecorder(_mediaStream!);

      _mediaRecorder!.addEventListener('dataavailable', (event) {
        final blobEvent = event as html.BlobEvent;
        _audioBlob = blobEvent.data;
      });

      _mediaRecorder!.addEventListener('stop', (event) {
        if (_audioBlob != null) {
          _recordedFilePath = html.Url.createObjectUrlFromBlob(_audioBlob!);
        }
        _stopMediaStream();
        _isRecording = false;
      });
    } catch (e) {
      print('Error initializing audio recorder: $e');
    }
  }

  @override
  Future<void> startRecording() async {
    if (_mediaRecorder != null && !_isRecording) {
      _mediaRecorder!.start();
      _isRecording = true;
    } else {
      print('Recorder is already running or not initialized.');
    }
  }

  @override
  Future<void> stopRecording() async {
    if (_mediaRecorder != null && _isRecording) {
      _mediaRecorder!.stop();
    } else {
      print('Recorder is not running.');
    }
  }



  void _stopMediaStream() {
    _mediaStream?.getTracks().forEach((track) {
      track.stop();
    });
    _mediaStream = null;
  }
}

